from .Singly_Linked_list import Node
from .Singly_Linked_list import SLL
